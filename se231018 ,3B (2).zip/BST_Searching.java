
class Node {
    int key;
    Node left, right;

    public Node(int key) {
        this.key = key;
        left = right = null;
    }
}

class BST {
    private Node root;

    public BST() {
        root = null;
    }

    public void insert(int key) {
        root = insertRec(root, key);
    }

    private Node insertRec(Node root, int key) {
        if (root == null) {
            root = new Node(key);
            return root;
        }
        if (key < root.key) {
            root.left = insertRec(root.left, key);
        } else if (key > root.key) {
            root.right = insertRec(root.right, key);
        }
        return root;
    }

    public boolean search(int key) {
        return searchRec(root, key);
    }

    private boolean searchRec(Node root, int key) {
        if (root == null) {
            return false;
        }
        if (key == root.key) {
            return true;
        }
        if (key < root.key) {
            return searchRec(root.left, key);
        }
        return searchRec(root.right, key);
    }
}

public class Main {
    public static void main(String[] args) {
        BST bst = new BST();
        int[] elements = {50, 30, 70, 20, 40, 60, 80};

        for (int elem : elements) {
            bst.insert(elem);
        }

        int searchKey = 40;
        if (bst.search(searchKey)) {
            System.out.println(searchKey + " is found in the BST.");
        } else {
            System.out.println(searchKey + " is not found in the BST.");
        }
    }
}
