import java.util.Scanner;

class Node {
    char data;
    Node next, prev;

    Node(char data) {
        this.data = data;
        this.next = this.prev = null;
    }
}

class DoublyLinkedList {
    Node head, tail, current;

    public DoublyLinkedList() {
        head = tail = current = null;
    }

    public void insert(char c) {
        Node newNode = new Node(c);
        if (current == null) {
            head = tail = current = newNode;
        } else {
            newNode.prev = current;
            newNode.next = current.next;
            if (current.next != null) {
                current.next.prev = newNode;
            } else {
                tail = newNode;
            }
            current.next = newNode;
            current = newNode;
        }
    }

    public void delete() {
        if (current == null) return;
        if (current.prev != null) {
            current.prev.next = current.next;
        } else {
            head = current.next;
        }
        if (current.next != null) {
            current.next.prev = current.prev;
        } else {
            tail = current.prev;
        }
        current = current.prev;
    }

    public void modify(char c) {
        if (current != null) current.data = c;
    }

    public void moveLeft() {
        if (current != null && current.prev != null) current = current.prev;
    }

    public void moveRight() {
        if (current != null && current.next != null) current = current.next;
    }

    public void print() {
        Node temp = head;
        while (temp != null) {
            System.out.print(temp.data + " ");
            temp = temp.next;
        }
        System.out.println();
    }

}

public class se231018 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        DoublyLinkedList editor = new DoublyLinkedList();
        boolean running = true;

        while (running) {
            System.out.println("\nText Editor:");
            editor.print();
            System.out.println("Commands: insert <char>, delete, left, right, exit");
            System.out.print("Enter command: ");
            String input = scanner.nextLine();
            String[] parts = input.split(" ");

            switch (parts[0].toLowerCase()) {
                case "insert":
                    if (parts.length > 1 && parts[1].length() == 1) {
                        editor.insert(parts[1].charAt(0));
                    }
                    break;
                case "delete":
                    editor.delete();
                    break;
                case "modify":
                    if (parts.length > 1 && parts[1].length() == 1) {
                        editor.modify(parts[1].charAt(0));
                    }
                    break;
                case "moveleft":
                    editor.moveLeft();
                    break;
                case "moveright":
                    editor.moveRight();
                    break;
                case "print":
                    editor.print();
                    break;
                case "exit":
                    running = false;
                    break;
                default:
                    System.out.println("Invalid command.");
            }
        }
        scanner.close();
    }
}
