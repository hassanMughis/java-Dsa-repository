public class se231018 {

    int[] grades = {75, 80, 90, 60, 85, 70, 95, 65, 88, 78};
    int index = 2;
    int newgrade = 85;

    public void updategrade() {
        if (newgrade < grades[index]) {
            grades[index] = newgrade;
        } else {
            System.out.println("entered grade is greater than the existing grade at index = " + index);
        }
    }

    public void print() {
        for (int grade : grades) {
            System.out.print(grade + " ");
        }
        System.out.println();
    }

    public void searchgrade(int targetgrade) {
        for (int i = 0; i < grades.length; i++) {
            if (grades[i] == targetgrade) {
                System.out.println("grade found at index: " + i);

                if (i - 2 >= 0) {
                    System.out.println("two left neighbors: " + grades[i - 2] + ", " + grades[i - 1]);
                } else if (i - 1 >= 0) {
                    System.out.println("one left neighbor: " + grades[i - 1] + ", no second left neighbor.");
                } else {
                    System.out.println("no left neighbors.");
                }

                if (i + 2 < grades.length) {
                    System.out.println("two right neighbors: " + grades[i + 1] + ", " + grades[i + 2]);
                } else if (i + 1 < grades.length) {
                    System.out.println("one right neighbor: " + grades[i + 1] + ", no second right neighbor.");
                } else {
                    System.out.println("no right neighbors.");
                }

                return;
            }
        }
        System.out.println("grade not found.");
    }

    public void averagegrade() {
        double sum = 0;
        double average;
        for (int i = 0; i < grades.length; i++) {
            sum += grades[i];
        }
        average = sum / grades.length;
        System.out.println("average grade: " + average);
    }

    public static void main(String[] args) {
        se231018 obj = new se231018();

        obj.searchgrade(90);
        obj.updategrade();
        obj.averagegrade();
        System.out.println("displaying values after the update of array:");
        obj.print();
    }
}
