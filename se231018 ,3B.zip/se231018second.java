class node {
    int studentId;
    node next;

    public node(int studentId) {
        this.studentId = studentId;
        this.next = null;
    }
}

class singlylinkedlist {
    node head;
    node tail;

    public void addstudent(int studentId) {
        node newnode = new node(studentId);
        if (head == null) {
            head = newnode;
            tail = newnode;
        } else {
            tail.next = newnode;
            tail = newnode;
        }
    }

    public int getlength() {
        int count = 0;
        node current = head;
        while (current != null) {
            count++;
            current = current.next;
        }
        return count;
    }

    public void deletefirststudent() {
        if (head != null) {
            head = head.next;
            if (head == null) {
                tail = null;
            }
        } else {
            System.out.println("no students to remove");
        }
    }

    public void findstudentatposition(int index) {
        int count = 1;
        node current = head;
        while (current != null) {
            if (count == index) {
                System.out.println("student at index " + index + ": se" + current.studentId);
                return;
            }
            count++;
            current = current.next;
        }
        System.out.println("invalid index");
    }

    public void merge(singlylinkedlist list2) {
        node current1 = this.head;
        node current2 = list2.head;
        singlylinkedlist mergedlist = new singlylinkedlist();

        while (current1 != null && current2 != null) {
            if (current1.studentId <= current2.studentId) {
                mergedlist.addstudent(current1.studentId);
                current1 = current1.next;
            } else {
                mergedlist.addstudent(current2.studentId);
                current2 = current2.next;
            }
        }

        while (current1 != null) {
            mergedlist.addstudent(current1.studentId);
            current1 = current1.next;
        }

        while (current2 != null) {
            mergedlist.addstudent(current2.studentId);
            current2 = current2.next;
        }

        this.head = mergedlist.head;
        this.tail = mergedlist.tail;
    }

    public void reverse() {
        node previous = null;
        node current = head;
        node next;
        tail = head;

        while (current != null) {
            next = current.next;
            current.next = previous;
            previous = current;
            current = next;
        }
        head = previous;
    }

    public void display() {
        node current = head;
        while (current != null) {
            System.out.print("se" + current.studentId + " --> ");
            current = current.next;
        }
        System.out.println("null");
    }
}


public class se231018second {
    public static void main(String[] args) {
        singlylinkedlist ll = new singlylinkedlist();
        ll.addstudent(231018);
        ll.addstudent(231019);
        ll.addstudent(231020);
        int length = ll.getlength();
        System.out.println("the number of students in the class is: " + length);
        ll.deletefirststudent();
        System.out.println("list after deleting the first student:");
        ll.display();
        ll.findstudentatposition(1);
        singlylinkedlist anotherll = new singlylinkedlist();
        anotherll.addstudent(231021);
        anotherll.addstudent(231022);
        System.out.println("merged list:");
        ll.merge(anotherll);
        ll.display();
        System.out.println("reversed list:");
        ll.reverse();
        ll.display();
    }
}
