class Node {
    int data;
    Node next;

    public Node(int data) {
        this.data = data;
        this.next = null;
    }
}

class Queue {
    Node front;
    Node rear;
    int size;

    public Queue() {
        front = rear = null;
        size = 0;
    }

    public void enqueue(int data) {
        Node newNode = new Node(data);
        if (rear == null) {
            front = rear = newNode;
        } else {
            rear.next = newNode;
            rear = newNode;
        }
        size++;
    }

    public int dequeue() {
        if (front == null) {
            return -1;
        }
        int data = front.data;
        front = front.next;
        size--;
        return data;
    }

    public void reverseFirstKElements(int k) {
        if (k > size) {
            return;
        }
        int[] tempArray = new int[k];
        for (int i = 0; i < k; i++) {
            tempArray[i] = dequeue();
        }
        for (int i = k - 1; i >= 0; i--) {
            enqueue(tempArray[i]);
        }
        for (int i = 0; i < size - k; i++) {
            enqueue(dequeue());
        }
    }

    public int getMinimum() {
        if (front == null) {
            return -1;
        }
        int min = front.data;
        Node current = front.next;
        while (current != null) {
            if (current.data < min) {
                min = current.data;
            }
            current = current.next;
        }
        return min;
    }

    public void printQueue() {
        if (front == null) {
            return;
        }
        Node temp = front;
        while (temp != null) {
            System.out.print(temp.data + " ");
            temp = temp.next;
        }
        System.out.println();
    }

    public static void main(String[] args) {
        Queue q = new Queue();
        q.enqueue(10);
        q.enqueue(20);
        q.enqueue(30);
        q.enqueue(40);
        q.enqueue(50);

        q.printQueue();
        q.reverseFirstKElements(3);
        q.printQueue();
        System.out.println(q.getMinimum());
    }
}
