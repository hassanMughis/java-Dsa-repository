public class se231018 {

    static class Node {
        int data;
        Node next;

        Node(int data) {
            this.data = data;
            this.next = null;
        }
    }

    Node head;

    public int getLength() {
        int length = 0;
        Node current = head;
        while (current != null) {
            length++;
            current = current.next;
        }
        return length;
    }

    public void printMiddle() {
        int length = getLength();
        if (length == 0) {
            System.out.println("List is empty.");
            return;
        }
        Node current = head;
        int middleIndex = length / 2;
        for (int i = 0; i < middleIndex; i++) {
            current = current.next;
        }
        System.out.println("Middle node: " + current.data);
    }

    public se231018 reverseList() {
        se231018 reversedList = new se231018();
        Node current = head;
        while (current != null) {
            Node newNode = new Node(current.data);
            newNode.next = reversedList.head;
            reversedList.head = newNode;
            current = current.next;
        }
        return reversedList;
    }

    public void removeDuplicates() {
        Node current = head;
        while (current != null && current.next != null) {
            if (current.data == current.next.data) {
                current.next = current.next.next;
            } else {
                current = current.next;
            }
        }
    }

    public se231018 mergeSortedLists(se231018 list2) {
        se231018 mergedList = new se231018();
        Node p1 = head;
        Node p2 = list2.head;
        Node current = null;

        while (p1 != null && p2 != null) {
            if (p1.data < p2.data) {
                if (mergedList.head == null) {
                    mergedList.head = new Node(p1.data);
                    current = mergedList.head;
                } else {
                    current.next = new Node(p1.data);
                    current = current.next;
                }
                p1 = p1.next;
            } else {
                if (mergedList.head == null) {
                    mergedList.head = new Node(p2.data);
                    current = mergedList.head;
                } else {
                    current.next = new Node(p2.data);
                    current = current.next;
                }
                p2 = p2.next;
            }
        }

        while (p1 != null) {
            current.next = new Node(p1.data);
            current = current.next;
            p1 = p1.next;
        }

        while (p2 != null) {
            current.next = new Node(p2.data);
            current = current.next;
            p2 = p2.next;
        }

        return mergedList;
    }

    public void deleteList() {
        head = null;
        System.out.println("List deleted.");
    }

    public void printList() {
        if (head == null) {
            System.out.println("List is empty.");
            return;
        }
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }

    public static void main(String[] args) {
        se231018 list1 = new se231018();
        list1.head = new Node(1);
        list1.head.next = new Node(2);
        list1.head.next.next = new Node(3);
        list1.head.next.next.next = new Node(4);
        list1.head.next.next.next.next = new Node(5);

        System.out.println("Original List:");
        list1.printList();

        System.out.println("Length of list: " + list1.getLength());
        list1.printMiddle();

        se231018 reversedList = list1.reverseList();
        System.out.println("Reversed List:");
        reversedList.printList();

        se231018 list2 = new se231018();
        list2.head = new Node(1);
        list2.head.next = new Node(1);
        list2.head.next.next = new Node(2);
        list2.head.next.next.next = new Node(2);
        list2.head.next.next.next.next = new Node(3);
        list2.head.next.next.next.next.next = new Node(3);
        System.out.println("List with duplicates:");
        list2.printList();
        list2.removeDuplicates();
        System.out.println("List after removing duplicates:");
        list2.printList();

        se231018 list3 = new se231018();
        list3.head = new Node(6);
        list3.head.next = new Node(8);
        list3.head.next.next = new Node(10);
        System.out.println("Merged List:");
        se231018 mergedList = list2.mergeSortedLists(list3);
        mergedList.printList();

        list1.deleteList();
    }
}

