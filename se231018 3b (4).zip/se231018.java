import java.util.Scanner;
import java.util.Map;
import java.util.HashMap;

public class se231018 {

    public static void insert(int[] LA, int K, int ITEM) {
        if (K < 0 || K >= LA.length) {
            System.out.println("Index K is out of range.");
            return;
        }
        if (ITEM <= 0) {
            System.out.println("ITEM must be a positive integer.");
            return;
        }
        if (ITEM < LA[K]) {
            for (int i = LA.length - 1; i > K; i--) {
                LA[i] = LA[i - 1];
            }
            LA[K] = ITEM;
            System.out.println("ITEM inserted at index " + K);
        } else {
            System.out.println(ITEM + " at index " + K + " is greater than the entered ITEM.");
        }
    }

    public static void search(int[] LA, int ITEM) {
        boolean found = false;
        for (int i = 0; i < LA.length; i++) {
            if (LA[i] == ITEM) {
                found = true;
                System.out.println("Item found at index " + i);
                if (i + 1 < LA.length) {
                    System.out.println("Right neighbor 1: " + LA[i + 1]);
                    if (i + 2 < LA.length) {
                        System.out.println("Right neighbor 2: " + LA[i + 2]);
                    } else {
                        System.out.println("No right neighbor.");
                    }
                } else {
                    System.out.println("No right neighbor.");
                }
                if (i - 1 >= 0) {
                    System.out.println("Left neighbor 1: " + LA[i - 1]);
                    if (i - 2 >= 0) {
                        System.out.println("Left neighbor 2: " + LA[i - 2]);
                    } else {
                        System.out.println("No left neighbor.");
                    }
                } else {
                    System.out.println("No left neighbor.");
                }
                break;
            }
        }
        if (!found) {
            System.out.println("Item not found in the array.");
        }
    }

    public static int findRepeated(int[] A) {
        boolean[] seen = new boolean[A.length];
        for (int i = 0; i < A.length; i++) {
            if (seen[A[i]]) {
                return A[i];
            }
            seen[A[i]] = true;
        }
        return -1;
    }

    public static void findRepeatedFive(int[] B) {
        Map<Integer, Integer> map = new HashMap<>();
        for (int num : B) {
            map.put(num, map.getOrDefault(num, 0) + 1);
        }
        System.out.println("Repeated numbers: ");
        for (Map.Entry<Integer, Integer> entry : map.entrySet()) {
            if (entry.getValue() > 1) {
                System.out.println(entry.getKey());
            }
        }
    }

    public static void transpose(int[][] matrix) {
        int rows = matrix.length;
        int cols = matrix[0].length;
        int[][] transposed = new int[cols][rows];
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                transposed[j][i] = matrix[i][j];
            }
        }
        System.out.println("Transposed Matrix:");
        for (int i = 0; i < transposed.length; i++) {
            for (int j = 0; j < transposed[i].length; j++) {
                System.out.print(transposed[i][j] + " ");
            }
            System.out.println();
        }
    }

    public static int leftDiagonalSum(int[][] matrix) {
        int sum = 0;
        int n = matrix.length;
        for (int i = 0; i < n; i++) {
            sum += matrix[i][i];
        }
        return sum;
    }

    public static int rightDiagonalSum(int[][] matrix) {
        int sum = 0;
        int n = matrix.length;
        for (int i = 0; i < n; i++) {
            sum += matrix[i][n - 1 - i];
        }
        return sum;
    }

    public static void main(String[] args) {
        int[] LA = {1, 3, 5, 7, 9};
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter index K: ");
        int K = sc.nextInt();
        System.out.print("Enter ITEM: ");
        int ITEM = sc.nextInt();
        insert(LA, K, ITEM);

        System.out.print("Enter ITEM to search: ");
        ITEM = sc.nextInt();
        search(LA, ITEM);

        int[] A = {1, 2, 3, 4, 5, 3};
        System.out.println("The repeated number is: " + findRepeated(A));

        int[] B = {1, 2, 3, 4, 5, 1, 2, 3, 4, 5};
        findRepeatedFive(B);

        int[][] matrix = {
                {1, 2, 3},
                {4, 5, 6},
                {7, 8, 9}
        };
        transpose(matrix);
        System.out.println("Left Diagonal Sum: " + leftDiagonalSum(matrix));
        System.out.println("Right Diagonal Sum: " + rightDiagonalSum(matrix));
    }
}
